-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- 主機: localhost
-- 產生時間： 2017 年 07 月 10 日 15:27
-- 伺服器版本: 10.2.6-MariaDB-log
-- PHP 版本： 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `health`
--
CREATE DATABASE IF NOT EXISTS `health` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `health`;

-- --------------------------------------------------------

--
-- 資料表結構 `class`
--
-- 建立時間: 2017 年 07 月 10 日 15:17
-- 最後更新: 2017 年 07 月 10 日 15:07
--

CREATE TABLE `class` (
  `id` int(10) UNSIGNED NOT NULL COMMENT '類別ID流水號',
  `class_name` varchar(100) COLLATE utf8mb4_unicode_nopad_ci NOT NULL COMMENT '類別名稱',
  `parent_id` int(10) UNSIGNED DEFAULT NULL COMMENT '上層流水號',
  `createdAt` datetime NOT NULL DEFAULT current_timestamp() COMMENT '新增時間',
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '更新時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_nopad_ci COMMENT='類別階層';

--
-- 資料表的匯出資料 `class`
--

INSERT INTO `class` (`id`, `class_name`, `parent_id`, `createdAt`, `updatedAt`) VALUES
(1, 'Thing', NULL, '2017-07-10 00:00:00', '2017-07-10 00:00:00'),
(2, 'Plant', 1, '2017-07-10 00:00:00', '2017-07-10 23:04:53'),
(3, 'Animal', 1, '2017-07-10 00:00:00', '2017-07-10 23:04:53'),
(4, 'Carnivore', 3, '2017-07-10 00:00:00', '2017-07-10 00:00:00'),
(5, 'Herbivore', 3, '2017-07-10 00:00:00', '2017-07-10 00:00:00');

-- --------------------------------------------------------

--
-- 資料表結構 `entity`
--
-- 建立時間: 2017 年 07 月 10 日 15:19
-- 最後更新: 2017 年 07 月 10 日 15:20
--

CREATE TABLE `entity` (
  `id` int(10) UNSIGNED NOT NULL COMMENT '實體ID流水號',
  `entity_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '實體名稱',
  `class_id` int(10) UNSIGNED NOT NULL COMMENT '類別 ID',
  `createdAt` datetime NOT NULL DEFAULT current_timestamp() COMMENT '新增時間',
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '更新時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='實體';

--
-- 資料表的匯出資料 `entity`
--

INSERT INTO `entity` (`id`, `entity_name`, `class_id`, `createdAt`, `updatedAt`) VALUES
(1, 'Grass', 2, '2017-07-10 00:00:00', '2017-07-10 00:00:00'),
(2, 'Tiger', 4, '2017-07-10 00:00:00', '2017-07-10 00:00:00'),
(3, 'Cow', 5, '2017-07-10 00:00:00', '2017-07-10 00:00:00');

--
-- 已匯出資料表的索引
--

--
-- 資料表索引 `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `entity`
--
ALTER TABLE `entity`
  ADD PRIMARY KEY (`id`);

--
-- 在匯出的資料表使用 AUTO_INCREMENT
--

--
-- 使用資料表 AUTO_INCREMENT `class`
--
ALTER TABLE `class`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '類別ID流水號', AUTO_INCREMENT=6;
--
-- 使用資料表 AUTO_INCREMENT `entity`
--
ALTER TABLE `entity`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '實體ID流水號', AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
